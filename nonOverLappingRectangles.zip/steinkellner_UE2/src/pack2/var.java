package pack2;

public class var {
	public static Panel2 boxShooterPanel;
	
	public static boolean correctInput = false;
	public static boolean exOnce = false, excludeUI = false;

	public static Box[] box;
	
	public static int inputCount = 10, actualFilled = 0, inputSize = 15, maxIterations, buttonX = 675;
}
